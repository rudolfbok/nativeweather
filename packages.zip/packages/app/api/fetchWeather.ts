import { useStorageString } from 'app/storage/useStorageString';
import { fetchOpenWeatherAPI } from './fetchOpenWeatherAPI';
import { fetchWeatherAPI } from './fetchWeatherAPI';

export const fetchWeather = (query: any) => {
	const [currentSource] = useStorageString('currentSource');

	if (currentSource === 'weatherapi') {
		fetchWeatherAPI(query);
	}

	if (currentSource === 'openweather') {
		fetchOpenWeatherAPI(query);
	}
};
