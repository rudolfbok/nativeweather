import { useOpenWeatherConditions } from './mapOpenWeatherConditions';
import { useWeatherAPIConditions } from './mapWeatherAPIConditions';

export const mapConditions = async (code: any, isDay: 0 | 1, source: string) => {
	const weatherAPICondition = useWeatherAPIConditions();
	const openWeatherCondition = useOpenWeatherConditions();

	if (source === 'weatherapi') {
		return weatherAPICondition(code, isDay);
	}

	if (source === 'openweather') {
		return openWeatherCondition(code);
	}
	throw new Error('Unknown weather source');
};
