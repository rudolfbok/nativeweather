const weatherAPIConditions: Record<number, string> = {
	1000: 'Clear',
	1003: 'Partly cloudy',
	1063: 'Light rain',
	1183: 'Rain',
	// …doplníš všechny kódy
};

const openWeatherConditions: Record<number, string> = {
	800: 'Clear',
	801: 'Partly cloudy',
	500: 'Light rain',
	501: 'Moderate rain',
	// …doplníš všechny kódy
};

export const mapConditions = (
	code: number,
	isDay?: 0 | 1,
	source: 'weatherapi' | 'openweather' = 'weatherapi'
): string => {
	if (source === 'weatherapi') {
		return weatherAPIConditions[code] || '';
	}
	if (source === 'openweather') {
		return openWeatherConditions[code] || '';
	}
	throw new Error('Unknown weather source');
};
