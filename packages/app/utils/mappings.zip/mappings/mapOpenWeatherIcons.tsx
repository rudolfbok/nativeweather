import { ClearDay } from 'app/components/icons/weather/clear/ClearDay';
import { ClearNight } from 'app/components/icons/weather/clear/ClearNight';
import { PartCloudsDay } from 'app/components/icons/weather/partclouds/PartCloudsDay';
import { PartCloudsNight } from 'app/components/icons/weather/partclouds/PartCloudsNight';
import { CloudyDay } from 'app/components/icons/weather/cloudy/CloudyDay';
import { CloudyNight } from 'app/components/icons/weather/cloudy/CloudyNight';
import { RainDay } from 'app/components/icons/weather/rain/RainDay';
import { RainNight } from 'app/components/icons/weather/rain/RainNight';
import { Snow } from 'app/components/icons/weather/snow/Snow';
import { StormDay } from 'app/components/icons/weather/storm/StormDay';
import { StormNight } from 'app/components/icons/weather/storm/StormNight';
import { FogDay } from 'app/components/icons/weather/fog/FogDay';
import { FogNight } from 'app/components/icons/weather/fog/FogNight';
import React from 'react';
import { OvercastDay } from 'app/components/icons/weather/overcast/OvercastDay';
import { OvercastNight } from 'app/components/icons/weather/overcast/OvercastNight';

interface OpenWeatherIconProps {
	code: string;
	width: number;
	height: number;
	strokeWidth?: number;
}

const iconsMap: Record<string, React.ComponentType<any>> = {
	'01d': ClearDay,
	'01n': ClearNight,
	'02d': PartCloudsDay,
	'02n': PartCloudsNight,
	'03d': CloudyDay,
	'03n': CloudyNight,
	'04d': OvercastDay,
	'04n': OvercastNight,
	'09d': RainDay,
	'09n': RainNight,
	'10d': RainDay,
	'10n': RainNight,
	'11d': StormDay,
	'11n': StormNight,
	'13d': Snow,
	'13n': Snow,
	'50d': FogDay,
	'50n': FogNight,
};

export const MapOpenWeatherIcons = ({ code, width, height, strokeWidth }: OpenWeatherIconProps) => {
	const IconComponent = iconsMap[code] || OvercastDay;
	return <IconComponent width={width} height={height} strokeWidth={strokeWidth!} />;
};
