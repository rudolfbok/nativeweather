// import { WeatherAlert } from './weatherAlert';

// export interface WeatherData {
// 	location: {
// 		name: string;
// 		region: string;
// 		country: string;
// 		lat: number;
// 		lon: number;
// 		localtimeEpoch: number;
// 		tzId: string;
// 	};
// 	current: {
// 		tempC: number;
// 		tempF: number;
// 		feelsLikeC: number;
// 		feelsLikeF: number;
// 		dewPointC: number;
// 		dewPointF: number;
// 		humidity: number;
// 		precipIn: number;
// 		precipMm: number;
// 		pressureInHg: number;
// 		pressureMb: number;
// 		uv: number;
// 		visibilityKm: number;
// 		visibilityMileses: number;
// 		windDegree: number;
// 		windDir: string;
// 		windKph: number;
// 		windMph: number;
// 		gustKph: number;
// 		gustMph: number;
// 		cloud: number;
// 		isDay: 0 | 1;
// 		condition: {
// 			text: string;
// 			code: number;
// 		};
// 	};
// 	forecast: {
// 		forecastday: {
// 			date: string;
// 			date_epoch: number;
// 			day: {
// 				maxtempC: number;
// 				maxtempF: number;
// 				mintempC: number;
// 				mintempF: number;
// 				maxwindKph: number;
// 				maxwindMph: number;
// 				daily_chance_of_rain: number;
// 				daily_chance_of_snow: number;
// 				daily_will_it_snow: 0 | 1;
// 				uv: number;
// 				avgvisibilityKm: number;
// 				avgvisibilityMileses: number;
// 				avghumidity: number;
// 				totalprecipMm: number;
// 				totalprecipIn: number;
// 				totalsnow_cm: number;
// 				condition: {
// 					text: string;
// 					code: number;
// 				};
// 			};
// 			hour: {
// 				time_epoch: number;
// 				tempC: number;
// 				tempF: number;
// 				isDay: 0 | 1;
// 				uv: number;
// 				chance_of_rain: number;
// 				chance_of_snow: number;
// 				snow_cm: number;
// 				condition: {
// 					code: number;
// 				};
// 			}[];
// 			astro: {
// 				sunrise: string;
// 				sunset: string;
// 				moon_phase: string;
// 				moon_illumination: number;
// 				moonrise: string;
// 				moonset: string;
// 				is_moon_up: 0 | 1;
// 			};
// 		}[];
// 	};
// 	alerts: {
// 		alert: WeatherAlert[];
// 	};
// }
