import { NormalizedWeather } from 'app/types/normalizedWeather';

const kphFromMs = (ms: number) => ms * 3.6;
const mphFromMs = (ms: number) => ms * 2.23694;
const milesFromMeters = (m: number) => m / 1609.34;
const inchesFromMm = (mm: number) => mm / 25.4;
const inHgFromHpa = (hpa: number) => hpa * 0.02953;

export const mapOpenWeatherApi = (data: any): NormalizedWeather => {
	return {
		location: {
			name: 'New York',
			region: 'New York',
			country: 'United States',
			lat: data.lat,
			lon: data.lon,
			localtimeEpoch: Math.floor(Date.now() / 1000) + data.timezone_offset,
			tzId: data.timezone,
		},
		current: {
			tempC: data.current.temp ?? 0,
			tempF: data.current.temp * 1.8 + 32,
			feelsLikeC: data.current.feels_like,
			feelsLikeF: data.current.feels_like * 1.8 + 32,
			dewPointC: data.current.dew_point,
			dewPointF: data.current.dew_point * 1.8 + 32,
			humidity: data.current.humidity,
			precipMm: data.current.rain?.['1h'] ?? data.current.snow?.['1h'] ?? 0,
			precipIn: inchesFromMm(data.current.rain?.['1h'] ?? data.current.snow?.['1h'] ?? 0),
			pressureMb: data.current.pressure,
			pressureInHg: inHgFromHpa(data.current.pressure),
			uv: data.current.uvi,
			visibilityKm: data.current.visibility / 1000,
			visibilityMiles: milesFromMeters(data.current.visibility),
			windDegree: data.current.wind_deg,
			windDir: '', // you must calculate from degrees if you want
			windKph: kphFromMs(data.current.wind_speed),
			windMph: mphFromMs(data.current.wind_speed),
			gustKph: data.current.wind_gust ? kphFromMs(data.current.wind_gust) : 0,
			gustMph: data.current.wind_gust ? mphFromMs(data.current.wind_gust) : 0,
			cloudCover: data.current.cloudCoverCover,
			isDay: data.current.dt > data.current.sunrise && data.current.dt < data.current.sunset ? 1 : 0,
			condition: {
				text: data.current.weather[0].description,
				code: data.current.weather[0].id,
			},
		},
		forecast: {
			forecastday: data.daily.map((day: any) => ({
				date: new Date(day.dt * 1000).toISOString().split('T')[0],
				date_epoch: day.dt,
				day: {
					maxTempC: day.temp.max,
					maxTempF: day.temp.max * 1.8 + 32,
					minTempC: day.temp.min,
					minTempF: day.temp.min * 1.8 + 32,
					maxWindKph: kphFromMs(day.wind_speed),
					maxWindMph: mphFromMs(day.wind_speed),
					dailyRainChance: day.pop * 100,
					dailySnowChance: day.snow ? 100 : 0,
					dailyWillItSnow: day.snow ? 1 : 0,
					uv: day.uvi,
					avgVisKm: 0,
					avgVisMiles: 0,
					avgHumidity: day.humidity,
					totalPrecipMm: day.rain ?? day.snow ?? 0,
					totalPrecipIn: inchesFromMm(day.rain ?? day.snow ?? 0),
					totalSnowCm: day.snow ?? 0,
					condition: {
						text: day.weather[0].description,
						code: day.weather[0].id,
					},
				},
				hour: data.hourly
					.filter((h: any) => new Date(h.dt * 1000).getDate() === new Date(day.dt * 1000).getDate())
					.map((hourData: any) => ({
						timeEpoch: hourData.dt,
						tempC: hourData.temp,
						tempF: hourData.temp * 1.8 + 32,
						isDay: hourData.dt > day.sunrise && hourData.dt < day.sunset ? 1 : 0,
						uv: hourData.uvi,
						chanceOfRain: hourData.pop * 100,
						chanceOfSnow: hourData.snow ? 100 : 0,
						snowCm: hourData.snow ?? 0,
						condition: {
							code: hourData.weather[0].id,
						},
					})),
				astro: {
					sunrise: new Date(day.sunrise * 1000).toLocaleTimeString(),
					sunset: new Date(day.sunset * 1000).toLocaleTimeString(),
					moonPhase: day.moon_phase,
					moonIllumunation: day.moon_phase * 100,
					moonRise: new Date(day.moonrise * 1000).toLocaleTimeString(),
					moonSet: new Date(day.moonset * 1000).toLocaleTimeString(),
					isMoonUp: 0,
				},
			})),
		},
		alerts: {
			alert: data.alerts ?? [],
		},
	};
};
