const API_KEY = 'e9408ab548e4513e4209f537b1d7109c';
const BASE_URL = 'https://api.openweathermap.org';

export const fetchOpenWeatherAPI = async (city) => {
	const geoUrl = `${BASE_URL}/geo/1.0/direct?q=${city}&limit=3&appid=${API_KEY}`;
	try {
		const geoResponse = await fetch(geoUrl);
		if (!geoResponse.ok) {
			throw new Error(`Error: ${geoResponse.status}`);
		}

		const geoData = await geoResponse.json();
		if (!geoData.length) {
			throw new Error('City not found');
		}
		const { lat, lon, name: cityName, country, state } = geoData[0];

		const locations = geoData.map(({ lat, lon, name, country }) => ({
			city: name,
			country,
			lat,
			lon,
			state,
		}));

		const weatherUrl = `${BASE_URL}/data/3.0/onecall?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric&exclude=minutely,alerts&lang=en`;
		const weatherResponse = await fetch(weatherUrl);
		if (!weatherResponse.ok) {
			throw new Error(`Error: ${weatherResponse.status}`);
		}
		const weatherData = await weatherResponse.json();

		return {
			weatherData,
			location: { city: cityName, region: state ?? '', country },
			latlon: { lat, lng: lon },
			locations,
			error: null,
		};
	} catch (error) {
		console.error('Failed to fetch geo data', error);
		return {
			error: error.message || 'An unknown error occurred',
		};
	}
};
