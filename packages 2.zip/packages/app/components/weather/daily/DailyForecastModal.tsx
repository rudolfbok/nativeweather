import { useTolgee } from '@tolgee/react';
import { useSwitchColors } from 'app/hooks/useSwitchColors';
import { WeatherData } from 'app/types/weatherData';
import { useWeatherConditions } from 'app/utils/mappings/mapConditions';
import { clsx } from 'clsx';
import { useEffect, useRef } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { RainCard, SnowCard, UVIndexCard, VisibilityCard, WindCard } from 'app/components/cards';
import { StyledModal } from 'app/components/common/styled/StyledModal';
import { DaysToggle } from './DaysToggle';
import { HourlyCarousel } from '../hourly/HourlyCarousel';
import { HourlyItem } from '../hourly/HourlyItem';
import { MainWeather } from '../main/MainWeather';
import { SmartSummary } from '../smart/SmartSummary';

interface DailyForecastModalProps {
	visible: boolean;
	day: WeatherData['forecast']['forecastday'][0] | null;
	days: WeatherData['forecast']['forecastday'];
	onSelectDay: (day: WeatherData['forecast']['forecastday'][0]) => void;
	onClose: () => void;
}

export const DailyForecastModal = ({ visible, day, days, onClose, onSelectDay }: DailyForecastModalProps) => {
	const scrollRef = useRef<ScrollView>(null);
	const tolgee = useTolgee();
	const getWeatherByCode = useWeatherConditions();
	const arrowColor = useSwitchColors('black', 'white');

	useEffect(() => {
		if (day && scrollRef.current) {
			scrollRef.current.scrollTo({ y: 0, animated: false });
		}
	}, [day]);

	if (!day) return null;

	const formatDate = (dateString: string) => {
		const date = new Date(dateString);

		return date.toLocaleDateString(tolgee.getLanguage(), {
			day: 'numeric',
			month: 'long',
			year: 'numeric',
		});
	};

	const getDayName = (date: string, short: boolean) => {
		return new Date(date).toLocaleString(tolgee.getLanguage(), {
			weekday: short ? 'short' : 'long',
		});
	};

	const getDisplayHourFromIndex = (hourIndex: number) => {
		if (tolgee.getLanguage() === 'en-US') {
			const hour12 = hourIndex % 12 || 12;
			const period = hourIndex < 12 ? 'AM' : 'PM';

			return `${hour12} ${period}`;
		}

		return hourIndex.toString();
	};

	return (
		<StyledModal
			visible={visible}
			ref={scrollRef}
			header={getDayName(day.date, false)}
			subHeader={formatDate(day.date)}
			onClose={onClose}
			daysToggle={<DaysToggle days={days} onSelectDay={onSelectDay} />}
		>
			<View className={clsx('w-full gap-4')}>
				<MainWeather
					currentTempC={day.day.maxtempC}
					currentTempF={day.day.maxtempF}
					minTempC={day.day.mintempC}
					minTempF={day.day.mintempF}
					maxTempC={day.day.maxtempC}
					maxTempF={day.day.maxtempF}
					isDay={1}
					code={day.day.condition.code}
					condition={getWeatherByCode(day.day.condition.code, 1)}
					arrowcolor={arrowColor}
					textColor="red"
					strokeWidth={StyleSheet.hairlineWidth}
					displayTime={false}
					feelslike={false}
				/>
				<SmartSummary
					minTempC={day.day.mintempC}
					maxTempC={day.day.maxtempC}
					minTempF={day.day.mintempF}
					maxTempF={day.day.maxtempF}
					rainPrecipMm={day.day.totalprecipMm}
					rainPrecipIn={day.day.totalprecipIn}
					snowPrecipCm={day.day.totalsnow_cm}
					snowPrecipIn={Number((day.day.totalsnow_cm * 0.393701).toFixed(2))}
					maxWindKph={day.day.maxwindKph}
					uvIndex={day.day.uv}
					avgVisibilityKm={day.day.avgvisibilityKm}
				/>
				<HourlyCarousel
					data={day.hour}
					renderItem={(hour, index) => (
						<HourlyItem
							key={index}
							hour={getDisplayHourFromIndex(index)}
							rainChance={hour.chance_of_rain}
							isDay={hour.isDay}
							code={hour.condition.code}
							tempC={hour.tempC}
							tempF={hour.tempF}
						/>
					)}
				/>
				<View
					className={clsx(
						'web:grid web:h-fit web:grid-cols-2 web:md:grid-cols-4 flex w-full flex-row flex-wrap justify-between gap-4'
					)}
				>
					{day.day.daily_chance_of_snow > day.day.daily_chance_of_rain ? (
						<SnowCard
							snowChance={day.day.daily_chance_of_snow}
							snowPrecipCm={day.day.totalsnow_cm}
							snowPrecipIn={Number((day.day.totalsnow_cm * 0.393701).toFixed(2))}
						/>
					) : (
						<RainCard
							rainChance={day.day.daily_chance_of_rain}
							rainPrecipMm={day.day.totalprecipMm}
							rainPrecipIn={day.day.totalprecipIn}
						/>
					)}

					<UVIndexCard data={day.day.uv} />
					<VisibilityCard visKm={day.day.avgvisibilityKm} visMiles={day.day.avgvisibilityMileses} />
					<WindCard
						windKm={Math.round(day.day.maxwindKph)}
						windMil={Math.round(day.day.maxwindMph)}
						details={false}
						currentWind={false}
					/>
				</View>
			</View>
		</StyledModal>
	);
};
