import Svg, { G, Path, Defs, LinearGradient, Stop, ClipPath } from 'react-native-svg';

export const OvercastNightLandscape = () => {
	return (
		<Svg width={600} height={710} viewBox="0 0 600 710" fill="none">
			<G clipPath="url(#clip0_24_178)">
				<Path fill="url(#paint0_linear_24_178)" d="M0 0H600V710H0z" />
				<Path
					d="M53.966 718.627c170.614-75.156 672.848-142.831 925.774-91.669 252.93 51.163 8.711 87.976 8.711 87.976L62.678 806.602l-8.712-87.975z"
					fill="#34516C"
				/>
				<Path
					d="M-203.562 711.725c-242.232-184.695 630.268-62.195 818.769 93.304 188.501 155.498-228.195 102.416-228.195 102.416l-603.258-53.988s254.916 42.962 12.684-141.732z"
					fill="#28445E"
				/>
			</G>
			<Defs>
				<LinearGradient id="paint0_linear_24_178" x1={300} y1={0} x2={300} y2={710} gradientUnits="userSpaceOnUse">
					<Stop stopColor="#2B4560" />
					<Stop offset={1} stopColor="#385877" />
				</LinearGradient>
				<ClipPath id="clip0_24_178">
					<Path fill="#fff" d="M0 0H600V710H0z" />
				</ClipPath>
			</Defs>
		</Svg>
	);
};
